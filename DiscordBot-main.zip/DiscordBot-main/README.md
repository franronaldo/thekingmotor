# Discord Bot con UptimeRobot y Flask
Este bot de Discord se mantiene activo gracias a un servidor Flask usado con UptimeRobot.